//
//  Video.swift
//  YouTuneAppCounsle
//
//  Created by Ahmed Salah on 30/08/2022.
//

import Foundation


class Video{
    var Title : String?
    var link : String?
    
    
    init(Title : String?, link: String?){
        self.Title = Title;
        self.link = link;
    }
}
