//
//  ViewController.swift
//  YouTuneAppCounsle
//
//  Created by Ahmed Salah on 30/08/2022.
//

import UIKit
import Firebase
import FirebaseDatabase
import AVKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    

    @IBOutlet weak var TableView: UITableView!
    
    var table = [Video]()
    var ref : DatabaseReference!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.delegate = self
        TableView.dataSource = self
        
        ref = Database.database().reference().child("videos")
        ref.observe(DataEventType.value) { (snapshot) in
            if snapshot.childrenCount > 0{
                self.table.removeAll()
                
                for video in snapshot.children.allObjects as! [DataSnapshot]{
                    let Object = video.value as! [String: AnyObject]
                    let Title = Object["Title"]
                    let videoLink = Object["link"]
                    let video = Video(Title: Title as! String, link: videoLink as! String)
                    self.table.append(video)
                    self.TableView.reloadData()
                }
            }
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return table.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        
        let video : Video
        video = table[indexPath.row]
        cell.titleLable.text = video.Title
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let videoUrl = URL(string: table[indexPath.row].link!)else{
            return
        }
        let player = AVPlayer(url: videoUrl)
        let controller = AVPlayerViewController()
        controller.player = player
        present(controller, animated: true){
            player.play()
        }
        
    }
    
    
    


}

